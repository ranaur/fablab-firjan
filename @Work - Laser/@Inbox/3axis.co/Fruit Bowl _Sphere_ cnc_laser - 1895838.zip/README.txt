Fruit Bowl "Sphere" cnc/laser by ZenziWerken on Thingiverse: https://www.thingiverse.com/thing:1895838

Summary:
This is my first try using 123D Make. It's quite intuitive to use, but you need a 3D-model, which I designed in 123D Design. Both tools are offered by Autodesk for free. 123D Make does offer a nesting function, but manual nesting still works better.My build was done on a desktop cnc-machine by Stepcraft from 6 mm birch plywood using a spiral-toothed 1.2 mm flute.Visit https://www.zenziwerken.de/en/ for more interesting designs.