Yoshi Coin - Super Mario World (Dragon Coin) by ihateu3 on Thingiverse: https://www.thingiverse.com/thing:4556742

Summary:
I added holes to the source file, and then offset the Z in my slicer to create a flat back for the coin to be mounted on a flat surface.  For the metallic coin color, I just changed the filament when the print got to that layer.I made this for my dogs house whos name is Yoshi, and the lettering can be found here if needed https://www.thingiverse.com/thing:4556744