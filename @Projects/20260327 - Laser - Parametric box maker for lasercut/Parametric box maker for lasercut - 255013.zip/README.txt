Parametric box maker for lasercut by jegb70 on Thingiverse: https://www.thingiverse.com/thing:255013

Summary:
Inspired by http://boxmaker.rahulbotics.com/ got to code this openscad box modeler.  Ideal for Lasercut stencils, in case you want a simple case with box joints. In future, I may add dovetail option.  If you are as lazy as me, you will avoid going to AI to create those matching paths, instead code something that can reuse for different sizes depending on your need.