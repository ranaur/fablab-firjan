Customizable Parts Box by Mutsuki on Thingiverse: https://www.thingiverse.com/thing:327393

Summary:
14.5.28   Data was revised.   The material is plywood 4mm  dimension255180135mmparts box Inside dimensionS  5035?135mmM  112?35?135mmL  17535?135mmLL  23935?135mm  Label paper size34?*21mm  