Laser cut Twirl by mistercrunch on Thingiverse: https://www.thingiverse.com/thing:389075

Summary:
It's a fancy laser cut twirl.