Laser cutting materiale template by Noloxs on Thingiverse: https://www.thingiverse.com/thing:728579

Summary:
A simple way of showcasing different possibilities with a laser cutter:  20 engraving shades  3 straight line flex cuts   2 parabolic shape flex cuts  10 square and circular cut sizes  6 font size tests