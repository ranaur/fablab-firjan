draw_box = 1; // [0:false, 1:true]
draw_banners = 1; // [0:none, 1:banner only, 2:text only, 3: both]

// number of rods per axis
nrods = 4;

// box height
boxh = 50;

// box width / depth
boxw = 50;

// color of dynamite rods
col_rod = "#CC0000";

// $fs value for rods - 0.1 for round ... >=3 for that edgy look
fs_rod = 3.0; // [0.05:highpoly, 3:lowpoly]

// squeeze factor: rods are scaled up by this factor so they intersect with each other
sqf = 1.45;

// Banner text
bnr_txt = " TNT TNT ";

// Banner font size
bnr_fnsz = 10.5;

// Font depth
fnt_d = 0.4;

// Banner height
bnr_h = 14;

// Banner depth
bnr_d = 2;

// Banner extension from box edge
bnr_x = 0.3;

bnr_bgcol = "#FFFFFF";
bnr_fncol = "#000000";

bnr_pin_h = 2;
bnr_pin_d = 2;

// fiddle tolerance
fiddle = 0.2;

// side clearance between inner box and outside
sc = 4;

// bottom height
bh = 0.6;

// snap width
sw = 1.8;

// snap height
sh = 2.2;


/* [Hidden] */
$fa = 4;
$fs = 0.1;
fid = fiddle;
use <Tiny5-Regular.ttf>

// inner width & height
iw = boxw-2*sc;
ih = boxh-2*bh;

// cutoff height
coh = boxh*0.5+bnr_pin_d*2;


d_rod = boxw / nrods;
bnr_true_w = 2*bnr_x + boxw;

/* a single dyamite rod */
module dynamite_rod()
{
    color(col_rod)
        translate([0,0,boxh*0.5])
            scale([sqf, sqf,1])
                cylinder(d=d_rod, h=boxh, center=true, $fs = fs_rod);
}

/* all rods together*/
module rods()
{
    sf_rods = boxw/((nrods-1)*d_rod + d_rod * sqf);
    
    scale([sf_rods, sf_rods, 1]) /* scale back down to fit boxw */
    translate([-0.5*boxw+d_rod*0.5, -0.5*boxw+d_rod*0.5, 0])
        for (i=[0:nrods-1])
            for (k=[0:nrods-1])
            {
                translate([i*d_rod,k*d_rod,0])
                    dynamite_rod();
            }
}

module box_snap()
{
    hfid = fid * 0.5;
    translate([0,0.4*iw,0])
    rotate([90,0,0])
    linear_extrude(iw*0.8)
    {
        polygon([
            [0,-2*sh], [0, 0], [hfid, 0], [hfid, sh-0.3], [hfid+0.3, sh],
            [sw, sh], [sw, -2*sh+sw]
        ]);
    }
}

module snaps()
{
    for (i=[0:3])
    {
        rotate([0,0,i*90])
            translate([-iw*0.5,0,coh])
                box_snap();
    }    
}



module box_bottom()
{
    union()
    {
        difference()
        {
                rods();
            // inner space
            translate([0,0,bh+0.5*ih])
                cube([iw, iw, ih], center=true);
            // top cutoff
            translate([0,0,0.5*boxh+coh])
                cube([boxw*2, boxw*2, boxh],center=true);
            banners(1);
        }
        snaps();
    }
}

module box_top()
{
    union()
    {
        difference()
        {
            rods();
            // inner space
            translate([0,0,bh+0.5*ih])
                cube([iw, iw, ih], center=true);
            // top cutoff
            translate([0,0,0.5*boxh+(boxh-coh)])
                cube([boxw*2, boxw*2, boxh],center=true);
            banners(1);
        }
        
    }
}


/**
 * never mind, this won't work, because it will create overhangs in the box
 */
module banner_chamfer(add_fiddle = 0)
{
    extlen = (add_fiddle + 0.7) * bnr_true_w;
    chx = bnr_h*0.3-1;
    chx2 = bnr_h*0.3;
    chy  = 1.7;
    
    translate([-extlen*0.5,0,bnr_h*0.5])
    rotate([0,90,0])
    linear_extrude(extlen)
        polygon([[-chx, 0], [-chx2, chy], [chx2, chy], [chx, 0]]);
}

module banner_pins(add_fiddle = 0)
{
    afh = add_fiddle * 0.5 * fid;
    af = add_fiddle * fid;
    
    for (i=[0:4])
        translate([-0.4*bnr_true_w+i*bnr_true_w*0.2,
            bnr_pin_h*0.5-fid, 0.5*bnr_h])
                rotate([90,0,0])
                    cylinder(h = bnr_pin_h+af,
                        d = bnr_pin_d+af, center=true);
/*    
    translate([-0.35 * bnr_true_w, bnr_pin_h*0.5+afh-0.1, 0.5*bnr_h])
        rotate([90,0,0])
            cylinder(h = bnr_pin_h+af, d = bnr_pin_d+af, center=true);
    translate([0, bnr_pin_h*0.5+afh-0.1, 0.5*bnr_h])
        rotate([90,0,0])
            cylinder(h = bnr_pin_h+af, d = bnr_pin_d+af, center=true);
    translate([0.35 * bnr_true_w, bnr_pin_h*0.5+afh-0.1, 0.5*bnr_h])
        rotate([90,0,0])
            cylinder(h = bnr_pin_h+af, d = bnr_pin_d+af, center=true);
*/
}

/* box for the banner
 * parameter add_fiddle is used for the negative cutout on the TNT rods
 */
module banner_box(add_fiddle = 0)
{
    af = add_fiddle * fid * 0.5;
    
    bnx = 0.5*(bnr_true_w-fid);
    bny = 0.5*(bnr_d-fid);
    bny2 = 0.5*(bnr_d-fid);
    bnx2 = 0.5*(bnr_true_w-fid-bnr_d*2);
    
    union()
    {
        translate([0,bnr_d*0.5,0])
            banner_pins(add_fiddle);
        linear_extrude(bnr_h+2*af)
            polygon([
                [-bnx, -bny2], [-bnx2, bny],
                [bnx2, bny],  [bnx, -bny2]
            ]);
    }
}


module banner_text(z_offset = 0.001)
{
    translate([(bnr_d+boxw)*0.5,0,0.5*(bnr_h-bnr_fnsz)])
        rotate([90,0,0])
            color(bnr_fncol)
                translate([-0.5*bnr_true_w,0,0.5*bnr_d-fnt_d])
                    linear_extrude(fnt_d)
                        offset(delta=0.001) /* fix broken mesh */
                        text(bnr_txt,font="Tiny5:style=Regular",size=bnr_fnsz,halign="center");

}

module banner_side(add_fiddle=0)
{
    //translate([-0.5*bnr_true_w,-0.5*bnr_d,0.5*(bnr_h-bnr_fnsz)])
    difference()
    {
        color(bnr_bgcol)
            banner_box(add_fiddle);
        
        if (add_fiddle == 0)
            banner_text();
    }
}

module banners(add_fiddle = 0)
{
    for (i=[0:3])
    {
        rotate([0,0,i*90])
            translate([0,-(bnr_true_w-bnr_d)*0.5,(boxw-bnr_h)*0.5])
            //translate([0,-boxw*0.5+0.7,(boxw-bnr_h)*0.5])
                banner_side(add_fiddle);
    }
}



/*
translate([100,100,0])
union()
{
    banners();
    rods();
}
*/

//banner_box();

if (draw_banners > 0)
{
    translate([0,0.5*bnr_h,0.5*bnr_d])
        rotate([90,0,0])
        {
            if (draw_banners == 1)
                banner_side();
            if (draw_banners == 2)
                banner_text(0);
            if (draw_banners == 3)
            {
                banner_text(0);
                banner_side();
            }
        }
}

if (draw_box > 0)
{
    translate([0,40*draw_banners,0])
    box_top();
    translate([4+boxw,40*draw_banners,0])
    box_bottom();
}

//#banners();
//banner_pins();

//banner_side();