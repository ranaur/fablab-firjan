Advent calendar by AuGr on Thingiverse: https://www.thingiverse.com/thing:7202815

Summary:
A modular advent calendar, that you can assemble in any shape you like!It has small, medium and large boxes. You can print as many of each as you want.