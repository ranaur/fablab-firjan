Customizable fancy pencil holder (you choose the number) by net_id on Thingiverse: https://www.thingiverse.com/thing:797104

Summary:
I was asked to make a 'nice' pencil holder. I provide the openscad file so you can set how many pencils you want it to hold. The customizer now allows you to change the slope  of the pencils and you can preview the stand with the pencils in it as well. 