grabbed minifig for customization by jweisberger on Thingiverse: https://www.thingiverse.com/thing:204733

Summary:
trying to get this into customizer  