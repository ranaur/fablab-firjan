Customizable Box by thingiverse on Thingiverse: https://www.thingiverse.com/thing:243650

Summary:
Click Open in Customizer and either opt for one of our preset shapes or draw your own. You can also adjust the size of the box.  