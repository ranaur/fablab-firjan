Handle for Allen/Hex Wrench/Key by JohnSL on Thingiverse: https://www.thingiverse.com/thing:151461

Summary:
I found this great handle http://www.thingiverse.com/thing:129760 for hex wrenches. However it was for only one size. I've create a customizable version so you can create your own for different size keys.