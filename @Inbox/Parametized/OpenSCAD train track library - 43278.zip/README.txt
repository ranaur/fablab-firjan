OpenSCAD train track library by srepmub on Thingiverse: https://www.thingiverse.com/thing:43278

Summary:
Parametric OpenSCAD library to generate (BRIO-compatible?) train track parts.Update 1: modified brick 4 so it better slices.Update 2: added parametric connector (thing 15165 is too large).Update 3: improved splitter, add some basic blocks, filter everything through netfabb, use more descriptive names, add some recent photos