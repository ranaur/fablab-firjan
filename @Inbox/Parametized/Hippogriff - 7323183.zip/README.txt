Hippogriff by mz4250 on Thingiverse: https://www.thingiverse.com/thing:7323183

Summary:
Want to access even more models not found here? Interested in supporting my efforts making free models for the world to enjoy? Check out my patreon page here:https://mz4250.com/Patrons have access to all my files in one place, a request board, as well as commercial options! Come check it out :-)