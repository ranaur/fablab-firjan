Blank Ring Customizer by ccox on Thingiverse: https://www.thingiverse.com/thing:2588069

Summary:
This is a quick way to create blank rings of specific size -- as a starting point for embellishment in 3D sculpting applications.The higher quality settings are really slow in Customizer and OpenSCAD, but necessary when you will be printing to an SLA printer.Ring sizes are from Wikipedia and several other sites (not all agree). If you find any mistakes, please let me know.