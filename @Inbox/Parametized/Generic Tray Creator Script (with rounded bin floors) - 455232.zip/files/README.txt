"generic_tray.py" is a SolidPython script that creates arbitrary grid
trays, useful for organizing lots of items, especially useful for creating
board game organizers.  

------
USAGE
------

***ALL UNITS ARE MILLIMETERS***

The tray will be specified by the dimensions of each row/column,
provided as two arrays.  If your tray is going to look like this:

               ----------------------------------
               |           |     |              |
        60mm   |           |     |              |
               ----------------------------------
               |           |     |              |
        60mm   |           |     |              |
               ----------------------------------
               |           |     |              |
               |           |     |              |
       100mm   |           |     |              |
               ----------------------------------
        30mm   |           |     |              |
               ----------------------------------
                   40mm      25mm     70mm      


Use the following command-line call to create the above (x-axis always first).
Make sure there are no spaces before or after the commas in the lists:


   python generic_tray.py [40,25,70] [30,100,60,60] 


You can add extra args to adjust floor- and wall-thickness, bin depth 
and how rounded you want the bins to be on the bottom:


   python generic_tray.py [40,25,70] [30,100] --depth=55 --outfile=mytray.scad


Type the following to see all options:


   python generic_tray.py --help


*** IF YOU DON'T WANT/CAN'T DO THE COMMAND-LINE THING, then follow the
    directions towards where CLI_OPTIONS and CLI_ARGS are set in the script.  
    You can remove all the CLI_* code and simply hardcode the tray size into 
    this script so you only have to double-click it to generate the SCAD file.
 

This will automatically generate a .scad file that can be loaded into 
OpenSCAD.  It will always ask if you want to also generate the .stl file,
which can be loaded into most 3D printing slicers, but this can be very 
slow unless you are using --round=0.  

It is recommended, if you are tweaking the tray dimensions and checking
resultant bin volumes, to always skip creating the STL (type nothing, press
enter), until you are happy with it, then re-run the last command and type
"y" before enter to generate the .stl.  





------
SETUP
------

The requirements to use generic_tray.py is:

   Python 2.X
   SolidPython
   OpenSCAD (optional, for quick viewing)

You must install the latest Python 2.X, such as python 2.7.8 (NOT python3.X):
(Skip this step on Linux or OSX -- python2.X is installed by default)

   https://www.python.org/downloads/

The only other requirement is to have SolidPython installed:

   https://github.com/SolidCode/SolidPython

You can simply copy the "solid" directory into your project directory (so
that the generic_tray.py script can call "import solid" and it will find
./solid/__init__.py).  Or within the SolidPython directory, you can run
"sudo python setup.py install".  This will install the "solid" directory
into your global site-packages directory so that it will be available no 
matter where you run generic_tray.py.

You can technically use the script to automatically generate .STL files, 
but the script is much quicker at producing .scad files which are loaded
and viewed in OpenSCAD very quickly.  As soon as you run the script, 
OpenSCAD will auto-update it's view as long as "Design"->"Automatic Reload
and Compile" is checked from the main menu.

In Ubuntu, install openscad through the package manager: 

   sudo apt-get install openscad

Otherwise, download it from here:

   http://www.openscad.org/downloads.html

