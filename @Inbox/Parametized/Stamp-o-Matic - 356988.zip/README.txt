Stamp-o-Matic by Benjamin on Thingiverse: https://www.thingiverse.com/thing:356988

Summary:
Stamps from pictures of your choice. Open your image with: http://agendaz.net/chaaawa/stamp-o-matic/Copy the output, open in Customizer, and paste in input.  Better pictures by Modorok