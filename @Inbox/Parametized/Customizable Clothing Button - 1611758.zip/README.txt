Customizable Clothing Button by GDop26 on Thingiverse: https://www.thingiverse.com/thing:1611758

Summary:
I've seen a lot of buttons online here but none of them were customizable, so I made an SCAD for one. Just a small thing to keep me busy while I look for more things to make customizable. There are controls for the diameter of the button, the thickness, how many sewing holes and the general aesthetic style. Nothing that fancy.I've attached a couple of remixes to showcase what kind of buttons you can make using this customizer. I might add more features in the future.