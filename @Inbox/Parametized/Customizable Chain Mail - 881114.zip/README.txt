Customizable Chain Mail by revar on Thingiverse: https://www.thingiverse.com/thing:881114

Summary:
My ring mail design looked nice, but it had problems with rings getting rotated.  I saw another design on thingiverse that had links that weren't susceptible to rotation, but the design wasn't configurable.  So I whipped this up in OpenSCAD.  A side benefit is that this design has a larger bottom surface area for the links, so it sticks to the build platform much better than my old ring mail.