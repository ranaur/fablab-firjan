/* [General Settings] */
// In mm, how thick should the walls be?
wall_thickness = 2; //[0.1:0.1:10]


/* [Card Dimensions] */
// In mm, how wide are the cards?
card_width = 65.5; //[200]

// In mm, how long are the cards?
card_length = 91; //[200]

// In mm, how much extra room should there be along a cards length in the tray/box?
card_length_margin = 1;//[0.5:0.5:10]


/* [Card Tray Settings] */
// In mm, how much deeper than the card width should the tray be?
tray_card_width_margin = 2.5; //[0.5:0.5:10]

// Calculated depth of the front tray.
tray_depth = card_width + tray_card_width_margin + wall_thickness;

// In mm, how tall should the walls of the tray be? This is the overall height including the floor.
tray_height = 34; //[200]

// How much of a curve should there be to the front of the tray? Set 0.1 for no curve.
tray_front_radius = 14; //[100]

// In mm, how thick should the floor be in the back of the tray?
tray_rear_floor_height = 4; //[100]

// In mm, how thick should the floor be in the front of the tray?
tray_front_floor_height = 6; //[100]


/* [Front Finger Cutout Settings] */
// Do you want a cutout in the front floor of the tray to make picking up the deck up easier?
create_front_finger_cutout = "No"; //["Yes", "No"]

// How wide should the cutout be?
front_finger_cutout_radius = 20; //[200]

// In mm, How deep should the cutout be?
front_finger_cutout_depth = 50; //[200]

// How rounded should the cutout corners be?
front_finger_cutout_corner_radius = 10; //[100]


/* [Tray Floor Cutout Settings] */
// Do you want to a cutout in the floor of the tray?
create_tray_floor_cutout = "Yes"; //["Yes", "No"]

// In mm, how long should the cutout be?
tray_floor_cutout_length = 65; //[100]

// In mm, how wide should the cutout be?
tray_floor_cutout_width = 40; //[100]

// In mm, how far from the back wall should the cutout be?
tray_floor_cutout_distance_from_back = 15; //[100]

// How wide should the circular inset be?
tray_floor_cutout_circle_radius = 0; //[100]

// In mm, how deep should the circular inset protrude?
tray_floor_cutout_circle_depth = 18; //[100]

// How rounded should the cutout corners be?
tray_floor_cutout_corner_radius = 5; //[100]


/* [Rear Tray Wall Cutout Settings] */
// Do you want to a cutout in the rear wall of the tray? If generating the rear box, use the Box Front Wall cutout instead.
create_rear_wall_cutout = "No"; //["Yes", "No"]

// How wide should the cutout be?
rear_tray_wall_cutout_radius = 60; //[100]

// In mm, How deep should the cutout be?
rear_tray_wall_cutout_depth = 20; //[100]

// How rounded should the cutout corners be?
rear_tray_wall_cutout_corner_radius = 20; //[100]


/* [Rear Box Settings] */
// Do you want to attach a box to the rear of the tray?
generate_rear_box = "No"; //["Yes", "No"]

// In mm, how tall should the walls of the box be? This is the overall height including the floor.
box_height = 70; //[200]

// In mm, how wide should the interior of the box be? (Thickness of the entire deck of cards placed in the box).
box_interior_space = 40; //[200]
box_width = box_interior_space + wall_thickness;

// In mm, how thick should the floor be in the back of the box?
box_rear_floor_height = 8; //[100]

// In mm, how thick should the floor be in the front of the box?
box_front_floor_height = 2; //[100]


/* [Box Front Wall Cutout Settings] */
// Do you want to a cutout in the front wall of the box?
create_front_wall_cutout = "Yes"; //["Yes", "No"]

// How wide should the cutout be?
front_box_wall_cutout_radius = 30; //[100]

// In mm, How deep should the cutout be?
front_box_wall_cutout_depth = 50; //[100]

// How rounded should the cutout corners be?
front_box_wall_cutout_corner_radius = 10; //[100]


/* [Box bottom Cutout Settings] */
// Do you want to a cutout in the floor of the box?
create_box_floor_cutout = "Yes"; //["Yes", "No"]

// In mm, how long should the cutout be?
box_floor_cutout_length = 60; //[100]

// In mm, how wide should the cutout be?
box_floor_cutout_width = 20; //[100]


/* [Hidden] */
// Calculated overall width of the deck boxes.
overall_width = card_length + card_length_margin + (wall_thickness * 2);

// Global resolution
$fs = 0.5;  // The minimum size for a fragment
$fa = 1;    // The minimum angle of a fragment


// ########## Project Space ##########
tray();
if(generate_rear_box == "Yes") translate([0, tray_depth, 0]) box();


// ########## Modules ##########
module tray(){
// Generate the final card tray.

	// Subtract the floor cutout from bottom of the tray.
	difference(){

		// Create a single object from the floor and the walls.
		union(){

			// Create the cutout in rear wall. This needs to be done before
			// joining the floor, so this shape does not cut into the floor.
			intersection(){
				tray_walls();
				if(create_rear_wall_cutout == "Yes") rear_tray_wall_cutout();
			}

			// Create the front finger cutout in the floor of the tray.
			intersection(){
				tray_floor();
				if(create_front_finger_cutout == "Yes") front_finger_cutout();
			}
		}

		// Create the shape of the floor cutout.
		if(create_tray_floor_cutout == "Yes") tray_floor_cutout();
	}	
}


module tray_shell(){
// Generate the basic shape of the tray, including the front curve.
	// Reset the shell's location so the front left corner is at the origin.
	translate([0, tray_depth, tray_height]) 

	// Rotate the shell so that the bottom is facing down and the front is facing the x axis.
	rotate([-90 ,0 ,-90]) 

	// Extrude the shell to the width of the tray.
	linear_extrude(overall_width)

	// Craft the profile of the shell.
	hull(){
			
		// Create a point that will be the rear, bottom of the tray.
		square(0.01);

		// Create a point that will be the rear, top of the tray (how tall).
		translate([0, tray_height, 0]) square(0.01);

		// Create a point that will be the front, bottom the tray (how deep).
		translate([tray_depth,tray_height,0]) square(0.01);

		// Create a circle that will be the front, top of the tray. Creates the curved front.
		intersection(){

			// Constrain the circle that creates the curve to the confines of the tray's dimensions.
			square([tray_depth, tray_height]); 

			// Create the circle
			translate([tray_depth - tray_front_radius, tray_front_radius, 0]) circle(r=tray_front_radius);
		}
	}
}


module tray_walls(){
// Generate the wallls of the tray.
	// Cut out the interior of the tray from the shell.
	difference(){

		// Generate the shell that defines the basic shape of the tray.
		tray_shell();

		// Position the negative space to account for wall_thickness and to ensure a clean cut in the front and bottom.
		translate([wall_thickness, -1, -1]){

			// Generate the negative space, oversizing the depth and height for a clean cut.
			// If generating a box behind the tray, also remove the rear wall of the tray.
			if (generate_rear_box == "Yes") {
				cube([card_length + card_length_margin,
									card_width + tray_card_width_margin + wall_thickness + 2,
									tray_height + 2]);
			}

			// Otherwise keep the rear wall.
			else {
				cube([card_length + card_length_margin,
									card_width + tray_card_width_margin + 1,
									tray_height + 2]);
			}
		}
	}	
}


module tray_floor(){
// Generate the tray floor.
	// Constrain the floor to the confines of the tray's shape. This creates a
	// smooth shape that confines to the curve at the front of the tray.
	intersection(){

		// Generate the shell that defines the confines of the tray's shape.
		tray_shell();

		// Join the front and back of the tray to create a solid floor.
		generate_floor(overall_width, tray_depth, tray_rear_floor_height, tray_front_floor_height);
	}
}


module generate_floor(width, depth, rear_floor_height, front_floor_height){
// Generate floor with an optional slope.
	// Join the front and back of the floor to create a solid floor.
	hull(){

		// Create the origin and height of the floor at the back side.
		translate([0, depth, 0]) cube([width, 0.1, rear_floor_height]);

		// Create the origin and height of the floor at the front side.
		cube([width, 0.1, front_floor_height]);
	}
}


module cutout_shape(width, depth, height, circle_radius, circle_depth, corner_radius, buffer=false){
// Generate the shape used for the various cutouts. 
// Set buffer to true to oversize the shape. Useful to avoid rounding exterior edges when using intersection.
	// Extrude the shape to the desired height.
	linear_extrude(height, convexity=2){

		// Round the corners of the shape.
		soften(corner_radius){

			// Subtract a circle from the front of the shape.
			difference(){

				// If the buffer is set to true, create a larger shape and offset it slightly to center it along the width.
				if(buffer)translate([-corner_radius, 0, 0]) square([width + (corner_radius * 2), depth + corner_radius]);	

				// If the buffer is set to false, create the shape to the specified dimensions.
				else square([width, depth]);	

				// Create and position the circle.
				translate([width / 2, circle_depth - circle_radius, 0]){
					circle(r=circle_radius);
					translate([0, -circle_depth / 2, 0]) square([circle_radius * 2, circle_depth], center=true);
				}
			}
		}
	}
}


module front_finger_cutout(){
// Create the shape of the finger cutout at the front of the tray.
	cutout_shape(overall_width,
				 tray_depth,
				 tray_height,
				 front_finger_cutout_radius,
				 front_finger_cutout_depth,
				 front_finger_cutout_corner_radius,
				 buffer=true);
}


module rear_tray_wall_cutout(){
// Create the shape of the cutout in the rear wall of the tray.
	// Raise the shape to the ground plane after rotating.
	translate([0, 0, tray_height])

	// Orient the shape so the cutout is inline with the rear wall.
	rotate([-90, 0, 0]) 

	// Create the shape.
	cutout_shape(overall_width,
				 tray_height,
				 tray_depth,
				 rear_tray_wall_cutout_radius,
				 rear_tray_wall_cutout_depth,
				 rear_tray_wall_cutout_corner_radius,
				 buffer=true);
}


module tray_floor_cutout(){
// Create the shape of the cutout in the floor of the tray.
	// Final position of the cutout shape, centered in the tray, offset from the back wall,
	// and slight below the tray floor for a clean cut.
	translate([(overall_width - tray_floor_cutout_length) / 2,
						tray_depth - wall_thickness - tray_floor_cutout_distance_from_back,
						-1])

	// Reset the position of the shape to the origin so it is easier to comprehend the math above.
	translate([0, -tray_floor_cutout_width, 0]){

		// Create the shape.
		cutout_shape(tray_floor_cutout_length,
			 	tray_floor_cutout_width,
			 	tray_height + 2,
			 	tray_floor_cutout_circle_radius,
			 	tray_floor_cutout_circle_depth,
				tray_floor_cutout_corner_radius,
			 	buffer=false);
	}
}


module box(){
// Create the walls of the box.
	box_rear_and_side_walls();
	box_front_wall();
	box_floor();
}


module box_floor(){
	difference(){
		// Create the floor of the box.
		generate_floor(overall_width,
									 box_width,
									 box_rear_floor_height,
									 box_front_floor_height);

		// Create the cutout.
		if(create_box_floor_cutout == "Yes") box_floor_cutout();
	}
}


module box_front_wall_cutout(){
// Create the shape of the cutout in the rear wall of the tray.
	// Raise the shape to the ground plane after rotating.
	translate([0, 0, box_height])

	// Orient the shape so the cutout is inline with the rear wall.
	rotate([-90, 0, 0]) 

	// Create the shape.
	cutout_shape(overall_width,
				 box_height,
				 wall_thickness,
				 front_box_wall_cutout_radius,
				 front_box_wall_cutout_depth,
				 front_box_wall_cutout_corner_radius,
				 buffer=true);
}


module box_floor_cutout(){
	// Center the cutout on the box floor and offset it below the floor for a clean cut.
	translate([(overall_width - box_floor_cutout_length) / 2, box_width / 2, -1])

	// Reset the location of the cutout so the above movements are easier to understand.
	translate([box_floor_cutout_width / 2, 0, 0])

	// Expand the shape of the cutout through the top of the floor.
	linear_extrude(box_height)

	// Create the shape of the cutout.
	hull(){

		// Create the first point in the cutout.
		circle(d=box_floor_cutout_width);

		// Create the second point in the cutout. 
		// Move the point so the resulting shape is the cutout length.
		translate([box_floor_cutout_length - box_floor_cutout_width, 0, 0]){
			circle(d=box_floor_cutout_width);
		}
	}
}


module box_front_wall(){
// Create the front wall of the box.
	// Create the cutout in the front wall
	intersection(){
		// Generate the front wall of the box.
		cube([overall_width, wall_thickness, box_height]);

		// Generate the cutout shape.
		if(create_front_wall_cutout=="Yes") box_front_wall_cutout();
	}
}

module box_rear_and_side_walls(){
// Creat the side and rear walls of the box.
	// Extrude to the height of the box.
	linear_extrude(box_height)

	// subtract the interior dimension othe box from the shell.
	difference(){
		// Create the box shell.
		square([overall_width, box_width]);

		// Create the negative space inside the box.
		translate([wall_thickness, 0, 0]){
			square([overall_width - (wall_thickness * 2), box_width - wall_thickness]);
		}
	}
}


module soften(amount){
// Round the corners of a 2D object.
	offset(r=amount) offset(r=-amount){
		children(0);
	}
}
