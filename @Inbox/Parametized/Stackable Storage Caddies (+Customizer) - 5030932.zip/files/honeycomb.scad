cellheight = 4; // depth
cols = 10;
rows = 21;

/* [hidden] */
cellrad = 8; // quarter inch diameter
cellthick = 2.2; // wall thickness

module honeycomb(rows,cols) {
	cellsize = cellrad-cellthick/2;
	voff = cellsize*1.5;
	hoff = sqrt(pow(cellsize*2,2)-pow(cellsize,2));

    for (i=[0:rows-1])
    {
        even = i % 2 ? cols-1 : cols;
		for (j=[0:even])
        {
			translate([j*hoff+i%2*(hoff/2),i*voff,0])
                rotate([0,0,30])
                    cylinder(r=cellrad-cellthick,h=cellheight,$fn=6);
		}
	}
}

honeycomb(rows,cols);
