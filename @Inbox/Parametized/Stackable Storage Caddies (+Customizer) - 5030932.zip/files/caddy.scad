/* [Container Dimensions] */

// Section
section = "container"; // [container,lid]
// Length (mm) of container
full_length = 240;
// Width (mm) of container
full_width = 160;
// Height (mm) of container
full_height = 80;

/* [Optional Settings] */

// Perimeter of gate - Cutouts will be offset this far from the outside walls
perimeter = 20;
// Cutout sides - Adds additional cutouts on the sides of the container
cutout_sides = 0; // [0:1:1]
// Cutout back - Adds additional cutout on the back of the container
cutout_back = 0; // [0:1:1]
// Cutout bottom - Bottom cutout is not controlled by perimeter distance
cutout_bottom = 0; // [0:1:1]

/* [Fine Tuning] */

// Radius (mm) of inside corners
inside_radius = 4;
// Thickness (mm) of walls - Outside corners are calculated based on walls
walls = 4;

// Rise height (mm) of teeth - The height of the teeth for stackable containers
teeth_rise = 1;
teeth_wall = walls / 2;

// Teeth Tolerance (mm) - the spacing between the teeth and their cutouts
tolerance = 0.2;

// Facet accuracy - Higher accuracy increases compiling time
facets = 32; // [8:8:128]
$fn = facets;

print_part();

module print_part()
{
    difference()
    {
        union()
        {
            if (section == "container")
            {
                body_top();
                body_central();
            }
            
            body_bottom();
        }
        
        // Front Cutout
        if (full_height > perimeter)
        {
            rotate([90,0,90])
            translate([perimeter, perimeter, 0])
                rounded_cube(full_width - (perimeter * 2), full_height, walls, inside_radius);
            
            // Teeth Fillets
            if (full_height >= (perimeter + (inside_radius * 2)))
            {
                // Right Fillet
                translate([0, perimeter - inside_radius, full_height - inside_radius + teeth_rise])
                    fillet_edge(walls);
            
                // Left Fillet
                translate([0, full_width + inside_radius - perimeter , full_height - inside_radius + teeth_rise])
                mirror([0,180,0])
                    fillet_edge(walls);
            }
        }
        
        // Back Cutout
        if (cutout_back && full_height > (perimeter * 2))
        {
            color("red")
            rotate([90,0,90])
            translate([perimeter, perimeter, full_length - walls * 2])
                rounded_cube(
                    full_width - (perimeter * 2),
                    full_height - (perimeter * 2),
                    walls*2,
                    inside_radius
                );
        }
        
        // Side Cutouts
        if (cutout_sides && full_height > (perimeter * 2))
        {
            rotate([90,0,0])
            translate([perimeter, perimeter, - full_width])
                rounded_cube(
                    full_length - (perimeter * 2),
                    full_height - (perimeter * 2),
                    full_width,
                    inside_radius
                );
        }
        
        // Bottom Cutout
        if (cutout_bottom)
        {
            translate([walls + teeth_wall, walls + teeth_wall, 0])
                rounded_cube(
                    full_length - (walls * 3),
                    full_width - (walls * 3),
                    walls,
                    inside_radius - teeth_wall
                );
        }
    }
}

module body_top()
{
    // Top Teeth
    translate ([teeth_wall, teeth_wall, full_height])
    {
        difference()
        {
            rounded_cube(
                full_length - walls,
                full_width - walls,
                teeth_rise,
                inside_radius + teeth_wall
            );
            
            translate([teeth_wall, teeth_wall, 0])
                rounded_cube(
                    full_length - (walls * 2),
                    full_width - (walls * 2),
                    teeth_rise,
                    inside_radius
                );
        }
    }
}

module body_bottom()
{
    difference()
    { 
        // Bottom Base
        rounded_cube(full_length, full_width, walls, inside_radius + walls);
    
        // Bottom Teeth Cutout
        translate([teeth_wall - tolerance, teeth_wall - tolerance, 0])
        {
            difference()
            {
                rounded_cube(
                    full_length - walls + (tolerance * 2),
                    full_width - walls + (tolerance * 2),
                    teeth_rise + 1,
                    inside_radius + teeth_wall + tolerance
                );
            
                translate([teeth_wall + (tolerance * 2), teeth_wall + (tolerance * 2), 0])
                    rounded_cube(
                        full_length - (walls * 2) - (tolerance * 2),
                        full_width - (walls * 2) - (tolerance * 2),
                        teeth_rise + 1,
                        inside_radius - tolerance
                    );
            }
        }
    }
}

module body_central()
{
    translate ([0,0,walls])
    {
        difference()
        {
            // Central Base
            rounded_cube(
                full_length,
                full_width,
                full_height - walls,
                inside_radius + walls
            );
            
            // Central Cutout
            translate([walls, walls, 0])
                rounded_cube(
                    full_length - (walls * 2),
                    full_width - (walls * 2),
                    full_height - walls,
                    inside_radius
                );
        }
    }
}

module rounded_cube(length, width, height, radius)
{
    radius = radius <= 0 ? 0.001 : radius;
    
    length = length - (radius * 2);
    width = width - (radius * 2);
    
    points = [[0,0,0], [length,0,0], [0,width,0], [length,width,0]];
    
    translate([radius,radius,0])
    {
        hull()
        {
            for(p = points)
            {
                translate(p)
                    cylinder(r = radius, h = height);
            }
        }
    }
}

module fillet_edge(length)
{
    resize([length,0,0])
    rotate([90,0,90])
    difference()
    {
        cube([inside_radius, inside_radius, teeth_wall]);
        cylinder(r = inside_radius, h = teeth_wall);
    }
}