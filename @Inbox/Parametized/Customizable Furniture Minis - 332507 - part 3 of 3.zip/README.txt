Customizable Furniture Minis by mathgrrl on Thingiverse: https://www.thingiverse.com/thing:332507

Summary:
Moving to new digs this summer? 3D-print some models of your furniture to plan out your space!  It's much more fun than Actually Packing Things.  In the Customizer you can design custom bookcases, sofas, beds, tables, desks, chairs, and more with your own dimensions and scaling, or choose from a library of stock furniture that includes standard bed sizes and IKEA bookcases.  MakerHome, Day 262:http://makerhome.blogspot.com/2014/05/day-262-customizable-furniture-minis.html