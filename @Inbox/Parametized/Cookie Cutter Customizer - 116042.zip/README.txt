Cookie Cutter Customizer by thingiverse on Thingiverse: https://www.thingiverse.com/thing:116042

Summary:
This allows you to draw freeform cookie cutters as a new extension of the Thingiverse Customizer app.  Want to include the new polygon_draw canvas in your own customizable thing?Click here to find out how.  