Catan Card Holder collapsible disassemble-able by RotorAlex on Thingiverse: https://www.thingiverse.com/thing:3173029

Summary:
I wanted a card tray holder that would fit in the game box! I have used it every game Ive played since and every one loves it and wants one! Need to print:Two of Part 1Two of Part 2Three of Part 3Enjoy!