Tetris Bookshelf by walter on Thingiverse: https://www.thingiverse.com/thing:46862

Summary:
I was thinking this would make a nice shelf for camera lenses or other small objects.  But my printer isn't large enough so I made a miniature test version instead.Printer:-- Afinia H480*Filaments:-- Up Yellow ABS-- Octave Gold ABS-- Octave Flourescent Red ABS-- Octave Flourescent Green ABS-- Octave Glow in the Dark Blue ABS-- Octave Blue ABS*affiliate link