Basic Stackable Bin by Printkaas on Thingiverse: https://www.thingiverse.com/thing:7332976

Summary:
Basic stackable bin.-160x100x61.5mm-1.5mm wall thickness04-11-2026 - Initial release.