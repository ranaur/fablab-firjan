Customizable Measuring Cup/Scoop by wstein on Thingiverse: https://www.thingiverse.com/thing:619626

Summary:
Why using universal measuring cup, when you can print one for your requirements. I am using it for washing powder and suchlike.  measuring cups for 10 - 150ml and 1/4 - 5 fl oz (US and Imperial) already generated. Or open it in the Customizer and generate your own measuring  cup.  The default wall thickness is 1mm. That is ok up to about 100ml for larger cups please use more wall thickness.  You may also like my new Customizable Measuring Spoon/Scoop (One or Two Ended)