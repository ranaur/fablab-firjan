Customizable Cable Holder by xifle on Thingiverse: https://www.thingiverse.com/thing:130495

Summary:
Use this customizable cable holder to tie your cables to your desk and prevent them from falling down. The current version only works for desks standing next to a wall and also acts as a spacer between wall and desk.  08/12/13: Version v2: Wall spacing is now at least thickness of the cable (+ 1.5mm space), everything else just makes no sense when desk stands next to a wall ;)05/03/17: Version v3: Fixed Customizer. Using the "Global" Tab seems to be broken on thingiverse