Stackable Board Game Component Tray by dougiebarx on Thingiverse: https://www.thingiverse.com/thing:4028790

Summary:
Stackable tray I whipped up to hold board game components. Can hold other things as well. Stacks nicely with itself. Enjoy!