Customizable Battery Case by walter on Thingiverse: https://www.thingiverse.com/thing:57281

Summary:
A customizable battery case to hold batteries while traveling.  Configurable for the number of batteries and type (as long as they're cylindrical).  This is a updated version of the customizable battery carrier ( http://www.thingiverse.com/thing:51376 ), re-designed to work without magnets as requested by GregFisk25.  