Customizable Cable Tie by jetty on Thingiverse: https://www.thingiverse.com/thing:58776

Summary:
MakerBot Customizer Challenge Runner-Up !A Cable Tie that works and can do the heavy lifting !   Can be customized for various purposes including a hole for a Screw and a Release Tab.