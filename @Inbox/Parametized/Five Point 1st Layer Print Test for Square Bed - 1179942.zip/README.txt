Five Point 1st Layer Print Test for Square Bed by Hideto on Thingiverse: https://www.thingiverse.com/thing:1179942

Summary:
1st Layer Print Test for Prusa i3,CoreXY,etc.It supported Customizer. You can make any size.