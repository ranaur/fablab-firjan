This To That - Universal Angle Bracket - Customizer by Torleif on Thingiverse: https://www.thingiverse.com/thing:1827297

Summary:
Universal connector of two hole patterns at a given anglehole chamfer and better edge case handling.Latest addition is negative radius makes holes without adding material aroundAs always. - All OPENSCADhttps://openscadsnippetpad.blogspot.com/