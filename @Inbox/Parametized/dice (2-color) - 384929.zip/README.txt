dice (2-color) by peanut on Thingiverse: https://www.thingiverse.com/thing:384929

Summary:
Just another customizable dieprint it in your favorite color and if you can with coloured dots (Dual Extrusion).  