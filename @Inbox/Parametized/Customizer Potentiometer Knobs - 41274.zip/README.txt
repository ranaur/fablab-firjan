Customizer Potentiometer Knobs by stevecooley on Thingiverse: https://www.thingiverse.com/thing:41274

Summary:
Here's the customizer version of the OpenSCAD parametric potentiometer knob generator. Enjoy!