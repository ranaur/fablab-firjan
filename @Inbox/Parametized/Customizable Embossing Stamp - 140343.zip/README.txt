Customizable Embossing Stamp by someandy on Thingiverse: https://www.thingiverse.com/thing:140343

Summary:
Use your own image to make an embossing stamp.   Features:   prints fully assembled  placement guide lines on the cover  rad old-school flip phone styling 