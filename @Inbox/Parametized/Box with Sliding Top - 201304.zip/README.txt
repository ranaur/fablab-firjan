Box with Sliding Top by txoof on Thingiverse: https://www.thingiverse.com/thing:201304

Summary:
A customizable box with a sliding top with a small catch.   I'd love to see your prints of this if you make one!  V2 includes now includes optional dividers.  Check the customizer to add more (or less) dividers.  The stl will create a box that holds 4 oblong pills.  Hit the customizer to adjust the dimensions.  