Miniature Table (Customizer) by deadlygeek on Thingiverse: https://www.thingiverse.com/thing:2736016

Summary:
A simple table built with customization controls. Change the dimensions of the table including length, width, height and colour.Mostly I build this as a refreshing on using openscad - I thought I would share it in the hopes that someone might find it useful.