Lego container (storage box) by rusanov079 on Thingiverse: https://www.thingiverse.com/thing:7328529

Summary:
Lego storage box with two size options. Scale 7:1.Sizes: 2x2 and 2x4.Minimum supports. Use pause and put pre-printed parts then resume print (see gallery).