Sewing box by NicApicella on Thingiverse: https://www.thingiverse.com/thing:946265

Summary:
Classic foldable/hinged sewing box (notions box).  Here's an animated GIF of the box in action!  Work in progress—what you see is the current beta.  See "Instructions" for BOM.  Since I assumed incorrect values for the width of the hex bolts' barrel, my proof-of-concept is—as you can see in the pictures—a bit crooked! Also, lids are missing at the moment…Working on fixing it soon! ^^