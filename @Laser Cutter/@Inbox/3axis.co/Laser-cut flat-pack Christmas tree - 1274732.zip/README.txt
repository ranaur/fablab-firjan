Laser-cut flat-pack Christmas tree by usedbytes on Thingiverse: https://www.thingiverse.com/thing:1274732

Summary:
Full project details here: https://hackaday.io/project/9222-laser-cut-mail-able-christmas-treeA laser-cuttable derivative of tc_fea's tree