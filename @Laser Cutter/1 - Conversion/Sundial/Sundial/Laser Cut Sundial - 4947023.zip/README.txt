Laser Cut Sundial by agancz on Thingiverse: https://www.thingiverse.com/thing:4947023

Summary:
This is a laser cut sundial.