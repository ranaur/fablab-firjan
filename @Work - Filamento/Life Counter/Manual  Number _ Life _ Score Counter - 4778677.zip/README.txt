Manual  Number / Life / Score Counter by MuchMore on Thingiverse: https://www.thingiverse.com/thing:4778677

Summary:
An good working manual counter. I made this for a friend, no idea for what board game he is using it. Important !! print with a 0.5mm line width (or 0.333mm or 1.0mm),  otherwise the spring will not print correct--Edit: now there are two version of the number ring. one going up and one downEdit_2: now there is a version with 4 digits