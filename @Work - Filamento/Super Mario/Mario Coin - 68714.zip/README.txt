Mario Coin by Ansarum on Thingiverse: https://www.thingiverse.com/thing:68714

Summary:
Coins from teh mario universe