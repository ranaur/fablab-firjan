Super Smash Bros Brawl Peach trophy by Xander779 on Thingiverse: https://www.thingiverse.com/thing:652630

Summary:
Original model from here: http://www.models-resource.com/wii/SuperSmashBrosBrawl/  I cleaned up the mesh and added a base for easier printing and display.