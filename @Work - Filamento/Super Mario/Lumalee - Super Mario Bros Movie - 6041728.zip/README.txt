Lumalee - Super Mario Bros Movie by chopancho on Thingiverse: https://www.thingiverse.com/thing:6041728

Summary:
Designed Lumalee after watching the Super Mario Bros movie. Amazing character.