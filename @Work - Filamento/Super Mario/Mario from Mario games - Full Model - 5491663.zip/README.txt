Mario from Mario games - Full Model by vincentw56 on Thingiverse: https://www.thingiverse.com/thing:5491663

Summary:
This is a remix from the excellent Mario model by bpitanga. This model is reassembled for printing as one unit.