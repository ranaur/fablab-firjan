Rosalina Figure by Shanold on Thingiverse: https://www.thingiverse.com/thing:4917621

Summary:
Rosalina ripped from table top sim monopoly gamer collectors edition. I cleaned it up in blender and thickend some areas to make it printable.  I'm printing it with a .2mm on my ender 3 v2 at 42MM tall. I used line supports no walls at 30% density No roof or floor. I'm very new to this design stuff So If I find anyway to improve this I will be updating it. If you find my thing helpfull feel free to leave a tip::Edits::Added a new pose that should print better at small sizes. 