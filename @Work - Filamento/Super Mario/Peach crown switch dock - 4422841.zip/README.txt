Peach crown switch dock by scooter1010 on Thingiverse: https://www.thingiverse.com/thing:4422841

Summary:
My sister asked me one day why isnt there a Princess Peach crown switch holder when there are Mario/Luigi/Wario/Waluigi cap holders, Thus this was born using tinkercad and an existing peaches crown file (linked in remix) I present to you  Princess Peach's switch holder!There is a small and a big version. This is without the jewels due to I mostly forgot to grab them when I was remixing (if your up for the challenge make them and add them as a remix for this) Printed with supports