Princess Peach tiara - Crown with headband, broach, earrings costume by flyattack on Thingiverse: https://www.thingiverse.com/thing:5078661

Summary:
Princess Peach costume as a tiara. Includes headband, tiara-sized crown, jewels, earrings and broach. All that is needed are earring stud mounts, pin backings and some glue to put it all together. Everything prints with no supports. Would suggest printing as lightweight as possible (eg. 1 perimeter, low infill %) so that it doesn't slide off the head easily. 