Princess Peach stencil 8 + 2D by Longquang on Thingiverse: https://www.thingiverse.com/thing:6435436

Summary:
Princess Peach stencil 8 + 2D