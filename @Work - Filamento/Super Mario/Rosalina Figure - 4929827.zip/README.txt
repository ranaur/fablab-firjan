Rosalina Figure by Shanold on Thingiverse: https://www.thingiverse.com/thing:4929827

Summary:
Rosalina model I fixed up for 3d printing If you find my thing helpfull feel free to leave a tip