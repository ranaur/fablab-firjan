Peach No legs by Guizmo12 on Thingiverse: https://www.thingiverse.com/thing:2602884

Summary:
Peach remix. "Print friendly"Resize and print. Best quality 0.1 with 140mm height Cuts added, easier to print