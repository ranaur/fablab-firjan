Princess Peach Remix -- fixed non-manifoldness by teslaandfriends on Thingiverse: https://www.thingiverse.com/thing:5398394

Summary:
Princess Peach Statue from donjakobo revised in meshlab to remove non-manifold edges and close resulting holes. G-code now generates successfully in Slic3r