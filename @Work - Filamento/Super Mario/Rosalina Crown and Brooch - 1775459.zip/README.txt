Rosalina Crown and Brooch by NickVarley on Thingiverse: https://www.thingiverse.com/thing:1775459

Summary:
Just a quick design I made in sketchup, painted and gave to a friend for their costume. Was pretty fun to make!