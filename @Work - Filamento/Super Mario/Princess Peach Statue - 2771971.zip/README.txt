Princess Peach Statue by donjakobo on Thingiverse: https://www.thingiverse.com/thing:2771971

Summary:
Remix of ZioVbc's model, but cleaned up the problems and aligned flat to built plate.This requires supports on the hair and face + hands in front.Printed at 0.15mm in PLA, 3% infill, 2 walls.