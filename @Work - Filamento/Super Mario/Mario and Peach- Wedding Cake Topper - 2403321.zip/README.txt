Mario and Peach- Wedding Cake Topper by derailed3d on Thingiverse: https://www.thingiverse.com/thing:2403321

Summary:
Requested by Kyle D.Mario and Peach cake topper for a wedding cake.This model was made for free. If you enjoyed this model, please consider helping me out by leaving a small tip by clicking here