Yoshi from Mario games - Full Model by vincentw56 on Thingiverse: https://www.thingiverse.com/thing:5477425

Summary:
This is a remix from the excellent Yoshi model by bpitanga. This model is reassembled for printing as one unit.