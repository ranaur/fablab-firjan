[SSBB] Peach by ThatOneGuyWhoDoesThings on Thingiverse: https://www.thingiverse.com/thing:1059690

Summary:
The princess can fight, I can tell you that much.Copyright Nintendo.