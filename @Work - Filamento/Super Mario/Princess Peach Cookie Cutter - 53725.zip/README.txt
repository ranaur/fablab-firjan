Princess Peach Cookie Cutter by MikeDX on Thingiverse: https://www.thingiverse.com/thing:53725

Summary:
Make some yummy princess biccies!