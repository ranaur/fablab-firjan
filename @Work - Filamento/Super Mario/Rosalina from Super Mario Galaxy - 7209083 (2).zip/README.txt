Rosalina from Super Mario Galaxy by bryanherger on Thingiverse: https://www.thingiverse.com/thing:7209083

Summary:
A model of Rosalina from the new Super Mario Galaxy movie.  I captured an image from the November 2025 trailer via IMDb, converted it to a 3D mesh using Meshy.ai, and did some cleanup in Blender.  I uploaded an image showing the image capture, the Meshy preview, and a print from my i3 Plus.  Note that the wand is too thin to print correctly - feel free to fix it and post a remix!