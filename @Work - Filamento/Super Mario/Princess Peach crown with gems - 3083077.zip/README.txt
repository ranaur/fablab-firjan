Princess Peach crown with gems by matsonic on Thingiverse: https://www.thingiverse.com/thing:3083077

Summary:
A mini Prince Peach Crow, the gems prints separatly so that you can have another filament color or paint them without having to get messy and the glue them into place.I make two small holes to fit a elastic band (not in the model) but you have the option to to that or glue it to a headband.