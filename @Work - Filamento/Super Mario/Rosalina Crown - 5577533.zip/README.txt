Rosalina Crown by birdinorbit on Thingiverse: https://www.thingiverse.com/thing:5577533

Summary:
Made for a halloween costume figured other's might want it. Uploaded a stl which may or may not be too small please scale to your desired size.Also uploaded the fusion 360 raw file if you want to edit it.