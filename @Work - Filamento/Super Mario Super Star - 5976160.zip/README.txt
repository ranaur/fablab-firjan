Super Mario Super Star by ReProps on Thingiverse: https://www.thingiverse.com/thing:5976160

Summary:
Modeled this up after seeing the Mario movie, my own take on the super star. Should be about 5 inches tall.