SimpleBase digital Sundial by mdnelson1234 on Thingiverse: https://www.thingiverse.com/thing:1468073

Summary:
A simple fast base for the MoJoptix digital sundial.   Faster Cheaper and does not need a jar.   Big shout out and props to mojooptix and her awesome sundial.   Wish I worked her hours .  Merci beaucouphttp://www.thingiverse.com/thing:1068443added the sketchup file incase you can't find a rock to tilt it proper.    Tilted upright for Utah.