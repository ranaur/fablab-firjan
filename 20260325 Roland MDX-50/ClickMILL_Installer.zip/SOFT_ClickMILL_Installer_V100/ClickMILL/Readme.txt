*****************************************************
           ClickMILL for Windows(R)
*****************************************************

WELCOME TO ClickMILL!

We recommend that you first read through this document to obtain a better understanding of ClickMILL.
This document provides an overview of the programs and their system requirements.

The explanations here assume that you are already familiar with using in Windows. For further information about using Windows, please refer the user's manual from Microsoft Corp.

If you are reading this file with Notepad, then go to the Edit menu and click "WordWrap" to select word-wrapping and make the displayed text easier to read.


Table of Contents

1.  Summary
2.  System requirements
3.  Supported Models
4.  Installation


* "Windows(R)" is registered trademark or trademark of Microsoft(R) Corporation in the United States and/or other countries.

Copyright (C) 2009,2010  Roland DG Corporation


R1-100924

========================================================
1.  Summary 
========================================================

ClickMILL is a program that lets you perform milling with ease, even without a model (3D shape data).
It allows you to perform drilling, chamfering, and other additional work for parts fashioned by milling, to perform surface leveling and other preparations before cutting a model, and to cut flat panels to size in rectangular or circular shapes.


========================================================
2.  System requirements
========================================================

- Either one of the following operating systems; Microsoft(R) Windows XP or Windows Vista or Windows 7 (32-bit or 64-bit)
  * As this software is a 32-bit application, it runs on WOW64 (or Windows-On-Windows 64) under the 64-bit version of Windows.
- The minimum required CPU for the operating system
- The minimum amount of required RAM for the operating system
- 10 Mbytes or more of free hard disk space for installation
- Video card with a resolution of 1024 x 768


========================================================
3.  Supported Models
========================================================

MDX-40A


========================================================
4.  Installation
========================================================

To install the ClickMILL, please follow the procedures described below. You cannot run the ClickMILL directly from this installation disk.

--------------------
- Installing the program from CD-ROM
Follow the instructions on the setup menu on the CD-ROM to install and set up.


========================================================

If you have questions or problems, please contact your local vendor or Roland sales center.
