*********************************************************
   Roland MODELA DRIVER for Windows(R) 64-bit
*********************************************************

We do recommend you to read through this document first for your better understanding of Roland MODELA DRIVER. This "Readme" file provides some important information to install DRIVER.

Explanation here is assuming that you are already familiar with operations on Windows. The further information about operation on Windows, please refer the user's manual from Microsoft Corp.

If you are reading this file with Notepad, check 'WordWrap' in Edit menu so that you can read more easily.


< Table of Contents >

1. Overview
2. Installing the Driver
3. Uninstalling the Driver)
4. Important Notes


* "Windows(R)" is registered trademark or trademark of Microsoft(R) Corporation in the United States and/or other countries.

(C) 2016 Roland DG Corporation

R2-240821


----------------------------------------

< 1. Overview >

This driver provides you the capability to output printing to the Roland MODELA machine from your Windows application software.


----------------------------------------

< 2. Installing the Driver >

*	Log on as a user with administrator rights.
*	If an older version of the driver is installed, uninstall it before you install the new one. For more information about how to remove the driver, refer to the next section, "Uninstalling the Driver."
*	Go to the Roland DG Corp. website (https://downloadcenter.rolanddg.com/) and download the driver for the machine you want to install, then specify the folder where you want to expand the downloaded file.

1.	Switch off the power to the machine, then detach the connector cable between the machine and the computer.
2.	Start Windows Explorer, then open the drive or folder where the setup program for the driver is located. (*)
3.	Double-click "SETUP64.EXE".
4.	The [User Account Control] appears, click [Yes].
5.	The Setup program for the driver starts.
6.	Click [Install].
7.	Choose the machine and connection port you're using, then click [Start].
8.	If the [Windows Security] appears, click [Install].
9.	After installation has finished, turn on the machine.
10.	Use the cable to make the connection between the computer and the machine.


----------------------------------------

< 3. Uninstalling the Driver >

*	Log on as a user with administrator rights.
*	Go to the Roland DG Corp. website (https://downloadcenter.rolanddg.com/) and download the driver for the machine you want to uninstall, then specify the folder where you want to expand the downloaded file.

1.	Switch off the power to the machine, then detach the connector cable between the machine and the computer.
2.	Start Windows Explorer, then open the drive or folder where the setup program for the driver is located. (*)
3.	Double-click "SETUP64.EXE".
4.	The [User Account Control] appears, click [Yes].
5.	The Setup program for the driver starts.
6.	Click [Uninstall].
7.	Select the machine to delete, then click [Start].
8.	If it is necessary to restart your computer, a window prompting you to restart it appears. Click [Yes].
9.	The uninstallation finishes after the computer restarts.


----------------------------------------

< 4. Important Notes >

- This driver does not support [Test Print].


========================================================

If you have further questions or problem, please contact to your local vendor or Roland sales center.
